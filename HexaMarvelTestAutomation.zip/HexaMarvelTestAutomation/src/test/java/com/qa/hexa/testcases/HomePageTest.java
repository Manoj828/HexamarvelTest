package com.qa.hexa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


import com.qa.hexa.base.TestBase;
import com.qa.hexa.pages.HomePage;

public class HomePageTest extends TestBase {

	HomePage homepage;
	
	public HomePageTest()
	{
		super();
	}
	
	
   @BeforeMethod()
   public void setup()
  {
	Initialisation();
	homepage = new HomePage();
  }
	

 /* @Test(priority=1)
  public void LogoTest()
  {
	 Assert.assertTrue(homepage.VerifyLogo());
  } 

  @Test(priority=2)
  public void TitleTest()
  {
	 String Title= homepage.VerifyTitle();
	 Assert.assertEquals(Title,"Hexamarvel Technologies | Outsourcing Agency for magento, wordpress, MEAN stack, mobile apps & digital marketing services in India");

  }

  
  @Test(priority=3)
  public void ixlLinkTest()
  {
	Assert.assertTrue(homepage.VerifyIXLlink()); 
	
  } */

  
  
  @Test(priority=4) // purposely failing this test in order to capture the screenshot on failure
  public void FooterLinkNoteTest()
  {
		
	Assert.assertFalse(homepage.VerifyFooterlinkNote()); 
  } 

 /* @Test(priority=5) 
  public void FooterLinkcountTest()
  {
	 int total= homepage.VerifyFooterLinks();
	 Assert.assertEquals(total, 6);
  }
  */



   @AfterMethod()
   public void tearup()
   {
	// driver.quit();
   }

	
	
	
}

package com.qa.hexa.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.hexa.base.TestBase;

public class HomePage extends TestBase{

	//Page Factory - Object repo
	@FindBy(xpath="//img[@alt='Hexamarvel Technologies']") 
	WebElement logo; 
	
	
	@FindBy(xpath="//h2[contains(text(),'IXL - iRobot')]") 
	WebElement IXLlink; 
	
	
	@FindBy(xpath="//h2[contains(text(),\"Let's marvel you!\")]") 
	WebElement FLink; 
	
	@FindBy(xpath="//div[@class='footer_right_inner row']/div/h6") 
	List<WebElement> FRLinks; 
	
	
	//Initializing the Page Objects:
	public HomePage(){ 
	PageFactory.initElements(driver, this);
	}
	
	//Actions:
	public boolean VerifyLogo()
	{
		return logo.isDisplayed();
	}
	
	public String VerifyTitle()
	{
		return driver.getTitle();
	}
		
	public boolean VerifyIXLlink()
	{
		return IXLlink.isDisplayed();
	}
		
		
	public boolean VerifyFooterlinkNote()
	{
		return FLink.isDisplayed();
	}	
	
	public int VerifyFooterLinks()
	{
		int count=FRLinks.size();
		
		//to print the links present in footer
		for(int i=0;i<count;i++)
		{
			String links=FRLinks.get(i).getText();
			System.out.println(links);
		}
		
		return count;
	}
	
	
	
	
	
}
